
thank you for using the fantasy_ asset pack...a collection of assets from the fantasy_ series' on itch.io!



stuff to know - tilesets

- each tile is 16 x 16 pixels...although some structures/objcets take up multiple tiles [e.g. fountain, big rock, etc]
- each tileset has a 1 tile [16 pixels] border...although some structures have details that are in the border-tile

stuff to know - animated tiles

- each animated tile has 4 frames
- bridge water animations are in a seperate tileset [e.g. forest_ [bridgeAnimatedTiles] to the static bridge tiles [e.g. forest_ [bridgeHorizontal]]

stuff to know - buildings [currently just the igloo]

- each building's sprite dimensions are multiples on 16 [they are compatible with tile-maps]
- each building animation has 8 frames [chimeny smoke]



future updates/asset packs - 

- dungeon_ [version 2.0]
- tundraDungeon_ [version 1.0]
- desertDungeon_ [version 1.0] [filled with runes and obelisks]

- forestVillage_ [version 2.0] [re-work to fit with the fantasy_ asset pack]
- desertVillage_ [version 1.0] 

- villageSprites_ [version 1.0] [a collection of villagers and merchants]
- fantasySprites_ [a collection of all of the sprite assets from the fantasy_ series']



...if you have any questions or requests you can contact me at analogstudios.inc@gmail.com





                                                             